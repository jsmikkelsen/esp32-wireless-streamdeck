// ESP32 Stream Deck / mixer enclosure. Units: mm.
// Export with -D 'part="top"' or -D 'part="bottom"'.
// Default view shows the assembled enclosure. Dimensions remain prototypes
// until measured against the actual switches, potentiometers, OLED and board.
part = "assembly"; // [assembly,top,bottom,exploded]
$fn = 64;
width = 150;
front_height = 18;
rear_height = 50;
angle = 22;
depth = (rear_height-front_height)/tan(angle);
panel_length = depth/cos(angle);
wall = 2.4;
floor_thickness = 3;
plate_thickness = 3;
clearance = 0.3; // per side, in panel coordinates
ledge_width = 4;
ledge_ramp_height = 6; // vertical rise: gradual, printable underside
mx_hole = 14.2;
mx_pitch = 19.05;
mx_clip_thickness = 1.5;
pot_hole = 7.5;
oled_window = [26,14];
usb_size = [14,8];
usb_x = width/2;
usb_bottom = 8;
pilot_diameter = 2.6; // tune to printer/material; direct M3 plastic thread
screw_clearance = 3.4;
pilot_depth = 11;
// A larger rear inset leaves room for the tilted panel's lower edge.
seat_front = 3;
seat_rear = 4.5;
key_x = 17.5;
key_v = 20;
pot_x = [110,130];
pot_v = [17,64];
oled_center = [120,40.5];
screw_points = [[9,9], [width-9,9],
                [9,panel_length-10.5], [width-9,panel_length-10.5]];

function top_z(y, drop=0) = front_height + y*tan(angle) - drop;
// Triangulate explicitly to avoid floating-point coplanarity warnings in CGAL.
function triangulate_faces(quads) = [for (f=quads) each
    [[f[0],f[1],f[2]], [f[0],f[2],f[3]]]];

// Solid with vertical walls, flat bottom and planar sloping upper face.
module wedge(x0, x1, y0, y1, bottom_z, drop=0) {
    polyhedron(points=[
        [x0,y0,bottom_z], [x1,y0,bottom_z],
        [x1,y1,bottom_z], [x0,y1,bottom_z],
        [x0,y0,top_z(y0,drop)], [x1,y0,top_z(y0,drop)],
        [x1,y1,top_z(y1,drop)], [x0,y1,top_z(y1,drop)]],
        faces=triangulate_faces([[0,3,2,1],[4,5,6,7],[0,1,5,4],
               [1,2,6,5],[2,3,7,6],[3,0,4,7]]), convexity=10);
}

module panel_transform() {
    translate([0,0,front_height]) rotate([angle,0,0]) children();
}

// Main cavity with a chamfered transition underneath the seating ledge.
// All ring levels are planar and all faces use the same exact vertices.
module main_cavity() {
    a = wall;
    b = wall+ledge_width;
    // Extend 0.25 mm into the seating cut to avoid coincident CSG faces.
    upper_drop = plate_thickness/cos(angle)-0.25;
    lower_drop = upper_drop+ledge_ramp_height;
    polyhedron(points=[
        [a,a,floor_thickness], [width-a,a,floor_thickness],
        [width-a,depth-a,floor_thickness], [a,depth-a,floor_thickness],
        [a,a,top_z(a,lower_drop)], [width-a,a,top_z(a,lower_drop)],
        [width-a,depth-a,top_z(depth-a,lower_drop)], [a,depth-a,top_z(depth-a,lower_drop)],
        [b,b,top_z(b,upper_drop)], [width-b,b,top_z(b,upper_drop)],
        [width-b,depth-b,top_z(depth-b,upper_drop)], [b,depth-b,top_z(depth-b,upper_drop)]],
        faces=triangulate_faces([[0,3,2,1],[8,9,10,11],
            [0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],
            [4,5,9,8],[5,6,10,9],[6,7,11,10],[7,4,8,11]]), convexity=10);
}

module seating_pocket() {
    panel_transform()
        translate([wall,seat_front,-plate_thickness])
        cube([width-2*wall,panel_length-seat_front-seat_rear,100]);
}

module screw_bosses() {
    intersection() {
        wedge(0,width,0,depth,0);
        panel_transform() translate([-10,-100,-100])
            cube([width+20,panel_length+200,100-plate_thickness]);
        union() {
            for (p=screw_points)
                translate([p[0]-6,p[1]*cos(angle)+3-6.5,0])
                cube([12,13,rear_height]);
        }
    }
}

module bottom_case() {
    difference() {
        union() {
            difference() {
                wedge(0,width,0,depth,0);
                main_cavity();
                seating_pocket();
            }
            screw_bosses();
        }
        // Axes normal to the panel, aligned to its screw holes.
        for (p=screw_points)
            panel_transform() translate([p[0],p[1],-plate_thickness-pilot_depth])
            cylinder(h=pilot_depth+0.02,d=pilot_diameter);
        // Rear opening; its 14 mm bridge needs checking in the slicer.
        translate([usb_x-usb_size[0]/2,depth-wall-0.1,usb_bottom])
            cube([usb_size[0],wall+0.2,usb_size[1]]);
    }
}

// Flat print orientation: underside z=0, face z=3.
module top_plate() {
    difference() {
        translate([wall+clearance,seat_front+clearance,0])
            cube([width-2*(wall+clearance),
                panel_length-seat_front-seat_rear-2*clearance,plate_thickness]);
        for (row=[0:2], col=[0:3]) {
            x = key_x+col*mx_pitch;
            v = key_v+row*mx_pitch;
            translate([x-mx_hole/2,v-mx_hole/2,-0.1])
                cube([mx_hole,mx_hole,plate_thickness+0.2]);
            // Underside relief gives the MX clips a 1.5 mm lip to grab.
            translate([x-16.5/2,v-16.5/2,-0.1])
                cube([16.5,16.5,plate_thickness-mx_clip_thickness+0.1]);
        }
        for (x=pot_x,v=pot_v)
            translate([x,v,-0.1]) cylinder(h=plate_thickness+0.2,d=pot_hole);
        translate([oled_center[0]-oled_window[0]/2,
            oled_center[1]-oled_window[1]/2,-0.1])
            cube([oled_window[0],oled_window[1],plate_thickness+0.2]);
        for (p=screw_points) {
            translate([p[0],p[1],-0.1])
                cylinder(h=plate_thickness+0.2,d=screw_clearance);
            // 90-degree M3 flat-head seat (6.4 mm head diameter).
            translate([p[0],p[1],plate_thickness-1.5])
                cylinder(h=1.51,d1=screw_clearance,d2=6.42);
        }
    }
}

if (part=="top") top_plate();
else if (part=="bottom") bottom_case();
else {
    color([0.19,0.22,0.27]) bottom_case();
    color([0.78,0.80,0.83]) panel_transform()
        translate([0,0,-plate_thickness+(part=="exploded"?30:0)]) top_plate();
}
