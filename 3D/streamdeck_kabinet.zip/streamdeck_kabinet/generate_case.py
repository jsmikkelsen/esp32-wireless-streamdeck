#!/usr/bin/env python3
"""Export and validate the enclosure, using only Python's standard library.

OpenSCAD 2021.01 or later is required as the CAD/CSG engine. No pip packages.
Run: python3 generate_case.py
Parameters: python3 generate_case.py --set 'pot_hole=8' --set 'clearance=0.4'
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile


def read_stl(path):
    raw = Path(path).read_bytes()
    if len(raw) >= 84:
        count = struct.unpack_from('<I', raw, 80)[0]
        if len(raw) == 84 + 50 * count:
            return [tuple(tuple(struct.unpack_from('<3f', raw, 84+i*50+12+j*12))
                          for j in range(3)) for i in range(count)]
    vertices = []
    for line in raw.decode('ascii').splitlines():
        tokens = line.split()
        if tokens and tokens[0] == 'vertex':
            vertices.append(tuple(map(float, tokens[1:])))
    if not vertices or len(vertices) % 3:
        raise ValueError(f'Invalid STL: {path}')
    return [tuple(vertices[i:i+3]) for i in range(0, len(vertices), 3)]


def cross_product(a, b, c):
    u = [b[i]-a[i] for i in range(3)]
    v = [c[i]-a[i] for i in range(3)]
    return (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])


def clean_triangulation(path):
    """Remove collinear CGAL triangles and conform their neighboring edges.

    OpenSCAD 2021 can export zero-area triangles on planar CSG faces. Removing
    those alone leaves T-junctions; split the exposed long edges at existing
    collinear vertices, without changing the solid's boundary.
    """
    original = read_stl(path)
    triangles = [t for t in original if sum(x*x for x in cross_product(*t)) >= 1e-16]
    counts = Counter(tuple(sorted((t[i],t[(i+1)%3])))
                     for t in triangles for i in range(3))
    exposed = [e for e,count in counts.items() if count == 1]
    vertices = set(v for e in exposed for v in e)
    subdivisions = {}
    for a,b in exposed:
        direction = tuple(b[i]-a[i] for i in range(3))
        length2 = sum(x*x for x in direction)
        intermediate = []
        for p in vertices:
            if p==a or p==b:
                continue
            t = sum((p[i]-a[i])*direction[i] for i in range(3))/length2
            if not 1e-7 < t < 1-1e-7:
                continue
            distance2 = sum((p[i]-a[i]-t*direction[i])**2 for i in range(3))
            if distance2 < 1e-12:
                intermediate.append((t,p))
        if intermediate:
            subdivisions[(a,b)] = [p for _,p in sorted(intermediate)]
    result = []
    for tri in triangles:
        polygon = []
        for i,a in enumerate(tri):
            b = tri[(i+1)%3]
            polygon.append(a)
            edge = tuple(sorted((a,b)))
            middle = subdivisions.get(edge,[])
            polygon.extend(middle if a==edge[0] else reversed(middle))
        if len(polygon)==3:
            result.append(tri)
        else:
            center = tuple(sum(p[i] for p in tri)/3 for i in range(3))
            result.extend((center,p,polygon[(i+1)%len(polygon)])
                          for i,p in enumerate(polygon))
    with Path(path).open('wb') as output:
        output.write(b'Streamdeck enclosure; standard-library triangulation cleanup'.ljust(80,b' '))
        output.write(struct.pack('<I',len(result)))
        for tri in result:
            normal = cross_product(*tri)
            length = math.sqrt(sum(x*x for x in normal))
            if not length:
                raise ValueError('Degenerate triangle after cleanup')
            values = [x/length for x in normal]+[x for p in tri for x in p]
            output.write(struct.pack('<12fH',*values,0))
    return dict(collinear_triangles_removed=len(original)-len(triangles),
                edges_subdivided=len(subdivisions))


def validate(path):
    triangles = read_stl(path)
    edges = Counter()
    directed = Counter()
    vertex_faces = defaultdict(list)
    adjacency = defaultdict(set)
    edge_faces = defaultdict(list)
    volume = 0.0
    for index, tri in enumerate(triangles):
        a, b, c = tri
        ab = [b[i]-a[i] for i in range(3)]
        ac = [c[i]-a[i] for i in range(3)]
        cross = (ab[1]*ac[2]-ab[2]*ac[1], ab[2]*ac[0]-ab[0]*ac[2],
                 ab[0]*ac[1]-ab[1]*ac[0])
        if sum(x*x for x in cross) < 1e-16:
            raise ValueError(f'Degenerate triangle {index} in {path}')
        volume += (a[0]*(b[1]*c[2]-b[2]*c[1])
                   +a[1]*(b[2]*c[0]-b[0]*c[2])
                   +a[2]*(b[0]*c[1]-b[1]*c[0]))/6
        for v in tri:
            vertex_faces[v].append(index)
        for u, v in ((a,b), (b,c), (c,a)):
            key = tuple(sorted((u,v)))
            edges[key] += 1
            directed[(u,v)] += 1
            edge_faces[key].append(index)
    bad = [e for e, count in edges.items() if count != 2]
    if bad:
        raise ValueError(f'{len(bad)} non-manifold/boundary edges in {path}')
    if any(directed[(u,v)] != 1 or directed[(v,u)] != 1 for u,v in edges):
        raise ValueError(f'Inconsistent winding in {path}')
    for faces in edge_faces.values():
        a,b = faces
        adjacency[a].add(b)
        adjacency[b].add(a)
    # At every vertex, incident faces must form one connected fan.
    for vertex, faces in vertex_faces.items():
        allowed = set(faces)
        found = {faces[0]}
        todo = [faces[0]]
        while todo:
            face = todo.pop()
            for other in adjacency[face] & allowed - found:
                found.add(other)
                todo.append(other)
        if found != allowed:
            raise ValueError(f'Non-manifold vertex {vertex} in {path}')
    remaining = set(range(len(triangles)))
    components = 0
    while remaining:
        components += 1
        todo = [remaining.pop()]
        while todo:
            for face in adjacency[todo.pop()] & remaining:
                remaining.remove(face)
                todo.append(face)
    if components != 1 or volume <= 0:
        raise ValueError(f'Expected one outward-oriented solid: {path}')
    points = list(vertex_faces)
    bounds = [[min(v[i] for v in points) for i in range(3)],
              [max(v[i] for v in points) for i in range(3)]]
    return dict(file=Path(path).name, triangles=len(triangles), vertices=len(points),
                edges=len(edges), watertight=True, vertex_manifold=True,
                consistent_winding=True, connected_components=components,
                signed_volume_mm3=round(volume,3), bounds_mm=bounds,
                dimensions_mm=[round(bounds[1][i]-bounds[0][i],3) for i in range(3)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--openscad', help='Path to OpenSCAD executable')
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--set', action='append', default=[], metavar='NAME=VALUE')
    args = parser.parse_args()
    candidates = [args.openscad, shutil.which('openscad'),
                  '/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD']
    executable = next((p for p in candidates if p and Path(p).is_file()), None)
    if executable is None:
        parser.error('OpenSCAD is required. Install it or pass --openscad /path/to/openscad.')
    source = Path(__file__).resolve().with_name('streamdeck_case.scad')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    # Each exported STL is validated before replacing the existing deliverable.
    with tempfile.TemporaryDirectory(prefix='streamdeck-') as temp:
        for part, name in [('top','streamdeck_top_plate.stl'),
                           ('bottom','streamdeck_bottom_case.stl')]:
            temporary = Path(temp)/name
            # Binary STL keeps vertex precision across triangulated CSG faces.
            command = [executable, '--export-format', 'binstl', '-o', str(temporary)]
            for definition in args.set:
                command += ['-D', definition]
            command += ['-D', f'part="{part}"', str(source)]
            subprocess.run(command, check=True)
            cleanup = clean_triangulation(temporary)
            report = validate(temporary)
            report['triangulation_cleanup'] = cleanup
            reports.append(report)
        for report in reports:
            shutil.copyfile(Path(temp)/report['file'], args.output_dir/report['file'])
    (args.output_dir/'mesh_validation.json').write_text(
        json.dumps({'method':'Exact STL vertices: edge incidence, winding, vertex fans, '
                            'connected components and signed volume. '
                            'Does not test arbitrary triangle self-intersections or hardware fit.',
                    'parameter_overrides':args.set, 'models':reports}, indent=2)+'\n')
    for report in reports:
        print(f"{report['file']}: manifold, {report['triangles']} triangles, "
              f"{report['dimensions_mm']} mm")


if __name__ == '__main__':
    main()
